# Comment peut-on permettre à l'utilisateur de sortir de la boucle
# en modifiant les lignes de code dans la boucle while ?

continuer = "o"
while continuer == "o":
    print("On continue !")
    input("Voulez-vous continuer ? o/n ")
# Demander le prénom, la ville de naissance et l'âge de la personne qui utilise le script
# Afficher ces trois informations
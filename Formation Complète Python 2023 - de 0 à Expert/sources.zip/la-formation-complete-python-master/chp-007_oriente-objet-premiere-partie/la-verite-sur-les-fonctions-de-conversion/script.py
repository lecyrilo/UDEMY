# class str:
#     pass

# a = 5
# a = str(a)
ma_liste = list("python")
print(ma_liste)

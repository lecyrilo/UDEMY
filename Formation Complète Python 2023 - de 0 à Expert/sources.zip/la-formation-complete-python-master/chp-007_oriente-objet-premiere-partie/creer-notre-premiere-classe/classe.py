class Voiture:
    marque = "Lamborghini"
    couleur = "rouge"

print(Voiture.marque)
print(Voiture.couleur)
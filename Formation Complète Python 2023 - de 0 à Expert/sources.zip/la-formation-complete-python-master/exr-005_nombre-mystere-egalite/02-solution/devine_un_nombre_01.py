nombre_mystere = 7

nombre_utilisateur = input("Quel est le nombre mystère ? ")

resultat = int(nombre_utilisateur) == nombre_mystere
print(resultat)
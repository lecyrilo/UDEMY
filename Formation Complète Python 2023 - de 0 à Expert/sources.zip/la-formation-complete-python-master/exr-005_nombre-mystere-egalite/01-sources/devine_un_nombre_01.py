nombre_mystere = 7

# Demander à l'utilisateur de deviner le nombre.
# Afficher si le nombre entré par l'utilisateur est égal au nombre mystère.
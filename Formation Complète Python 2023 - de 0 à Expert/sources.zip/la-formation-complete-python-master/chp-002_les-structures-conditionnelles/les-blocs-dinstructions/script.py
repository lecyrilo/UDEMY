age = 20
langage == "Python"

if age >= 18:
    print("Vous êtes majeur !")
    if langage == "Python":
        print("Vous pouvez rentrer")

print("Le script est terminé")
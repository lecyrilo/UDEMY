age = 20
if age >= 18:
    print("Vous êtes majeur !")
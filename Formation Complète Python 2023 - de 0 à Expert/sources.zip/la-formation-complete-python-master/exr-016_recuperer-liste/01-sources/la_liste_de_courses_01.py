import os
 
dossier_courant = os.path.dirname(__file__)
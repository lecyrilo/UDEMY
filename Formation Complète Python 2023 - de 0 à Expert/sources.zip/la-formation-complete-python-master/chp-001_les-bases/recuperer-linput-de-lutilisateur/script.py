nombre = input("Entrez un nombre: ")
print(nombre)
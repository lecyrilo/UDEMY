nombre_mystere = 7
nombre_utilisateur = input("Quel est le nombre mystère ? ")

# Afficher à l'aide d'une structure conditionnelle si le nombre entré par l'utilisateur est plus grand,
# plus petit ou égal au nombre mystère.

"""
Dans cet exercice vous devez afficher les lettres du mot 'Python' dans le sens inverse.
Votre script devra donc afficher :
n
o
h
t
y
P
"""
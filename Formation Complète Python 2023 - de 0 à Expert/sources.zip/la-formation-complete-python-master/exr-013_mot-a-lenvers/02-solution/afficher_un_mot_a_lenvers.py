# Solution 1
mot = "Python"
for lettre in reversed(mot):
    print(lettre)

# Solution 2
mot = "Python"
for lettre in mot[::-1]:
    print(lettre)
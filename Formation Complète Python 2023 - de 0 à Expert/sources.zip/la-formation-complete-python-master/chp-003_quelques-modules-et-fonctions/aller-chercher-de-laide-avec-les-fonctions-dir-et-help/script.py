import random
from pprint import pprint
print(dir(random))
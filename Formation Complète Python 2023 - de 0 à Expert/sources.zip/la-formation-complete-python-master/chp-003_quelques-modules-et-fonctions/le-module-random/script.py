import random

r = random.randint(0, 1)
r = random.uniform(0, 1)
r = random.randrange(2)
r = random.randrange(0, 101, 10)
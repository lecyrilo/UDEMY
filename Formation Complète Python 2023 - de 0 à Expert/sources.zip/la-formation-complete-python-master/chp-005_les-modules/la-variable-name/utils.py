def addition(a, b):
    return a + b

if __name__ == "__main__":
    print(addition(4, 5))
liste = ["Python", "C++", "Java"]
liste[0]  # "Python"
liste[1]  # "C++"
liste[2]  # "Java"
liste[-1]  # "Java"
liste[-2]  # "C++"
liste[-3]  # "Python"
liste[-4]  # Erreur ! Indice hors des limites de la liste
liste[3]  # Erreur ! Indice hors des limites de la liste
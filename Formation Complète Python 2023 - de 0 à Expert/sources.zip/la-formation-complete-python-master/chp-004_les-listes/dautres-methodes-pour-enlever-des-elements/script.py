employes = ["Carlos", "Max", "Martine", "Patrick", "Alex"]
element = employes.pop(-1)  # retire le dernier élément de la liste (ici, "Alex") et le retourne dans la variable 'element'
print(element)  # affiche 'Alex'
employes.clear()  # supprime tous les éléments de la liste
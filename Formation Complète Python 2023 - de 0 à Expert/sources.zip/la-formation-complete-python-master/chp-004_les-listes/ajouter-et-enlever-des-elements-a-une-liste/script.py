liste = [5]
liste.append(3)  # [5, 3]
liste.extend([20, "Python"])  # [5, 3, 20, "Python"]
liste.remove("Python")  # [5, 3, 20]
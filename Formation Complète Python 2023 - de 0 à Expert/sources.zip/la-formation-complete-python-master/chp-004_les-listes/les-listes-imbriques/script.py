liste = ["Python", ["Java", "C++", ["C"]], ["Ruby"]]

liste[0]  # 'Python'
liste[-1][0]  # 'Ruby'
liste[0][0:2]  # 'Py'
liste[1][1]  # 'C++'
liste[1][:2]  # ['Java', 'C++']